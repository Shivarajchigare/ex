const express = require("express");
const bodyParser = require("body-parser");
const cron = require("node-cron");

const app = express();
app.use(bodyParser.json());

const PORT = 3000;

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
let expenses = []; // In-memory storage
const categories = ["Food", "Travel", "Utilities", "Shopping", "Other"]; // Predefined categories
let idCounter = 1; // Auto-increment ID
app.post("/expenses", (req, res) => {
    const { category, amount, date } = req.body;

    // Validate category
    if (!categories.includes(category)) {
        return res.status(400).json({ status: "error", data: null, error: "Invalid category" });
    }

    // Validate amount
    if (amount <= 0) {
        return res.status(400).json({ status: "error", data: null, error: "Amount must be positive" });
    }

    // Create new expense
    const expense = { id: idCounter++, category, amount, date: new Date(date).toISOString() };
    expenses.push(expense);

    res.json({ status: "success", data: expense, error: null });
});
app.get("/expenses", (req, res) => {
    const { category, start_date, end_date } = req.query;

    let filteredExpenses = expenses;

    // Filter by category
    if (category) {
        filteredExpenses = filteredExpenses.filter((exp) => exp.category === category);
    }

    // Filter by date range
    if (start_date) {
        filteredExpenses = filteredExpenses.filter((exp) => new Date(exp.date) >= new Date(start_date));
    }
    if (end_date) {
        filteredExpenses = filteredExpenses.filter((exp) => new Date(exp.date) <= new Date(end_date));
    }

    res.json({ status: "success", data: filteredExpenses, error: null });
});
app.get("/expenses/analysis", (req, res) => {
    const total = expenses.reduce((sum, exp) => sum + exp.amount, 0);

    const byCategory = expenses.reduce((acc, exp) => {
        acc[exp.category] = (acc[exp.category] || 0) + exp.amount;
        return acc;
    }, {});

    const highestCategory = Object.keys(byCategory).reduce((a, b) =>
        byCategory[a] > byCategory[b] ? a : b
    );

    res.json({
        status: "success",
        data: {
            total,
            byCategory,
            highestCategory,
        },
        error: null,
    });
});
cron.schedule("0 0 * * *", () => { // Daily at midnight
    const today = new Date().toISOString().split("T")[0];
    const dailyExpenses = expenses.filter((exp) => exp.date.startsWith(today));
    const dailyTotal = dailyExpenses.reduce((sum, exp) => sum + exp.amount, 0);

    console.log(`Daily Report for ${today}: Total = ${dailyTotal}`);
});

// Weekly summary (Monday at 00:00)
cron.schedule("0 0 * * 1", () => {
    const lastWeek = new Date();
    lastWeek.setDate(lastWeek.getDate() - 7);

    const weeklyExpenses = expenses.filter((exp) => new Date(exp.date) >= lastWeek);
    const weeklyTotal = weeklyExpenses.reduce((sum, exp) => sum + exp.amount, 0);

    console.log(`Weekly Report: Total = ${weeklyTotal}`);
});
